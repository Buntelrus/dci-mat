function helloWorld(): void {
    const a = 0
    console.log('helloWorld has been run')
}
helloWorld()
